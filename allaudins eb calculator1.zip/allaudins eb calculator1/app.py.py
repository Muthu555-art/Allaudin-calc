from flask import Flask, render_template, request, redirect, url_for, session, send_file, jsonify
from flask_session import Session
from io import BytesIO
from fpdf import FPDF
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a secure secret key
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Simple user store: EB number as username and password
# In production, use a database and hashed passwords
users = {}

@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('calculator'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        eb_number = request.form.get('eb_number')
        if not eb_number:
            error = "Please enter your EB number."
        else:
            # Register user if not exists
            if eb_number not in users:
                users[eb_number] = eb_number  # password same as EB number
            # Login check
            if eb_number == users.get(eb_number):
                session['user'] = eb_number
                return redirect(url_for('calculator'))
            else:
                error = "Invalid EB number."
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/calculator', methods=['GET', 'POST'])
def calculator():
    if 'user' not in session:
        return redirect(url_for('login'))

    result = None
    steps = None
    last_month = None
    this_month = None

    if request.method == 'POST':
        last_month = request.form.get('last_month')
        this_month = request.form.get('this_month')

        try:
            last_month_val = float(last_month)
            this_month_val = float(this_month)
            difference = this_month_val - last_month_val
            multiplied = difference * 15
            final_amount = multiplied / 5

            steps = {
                "Last Month Units": last_month_val,
                "This Month Units": this_month_val,
                "Difference (This - Last)": difference,
                "Difference x 15": multiplied,
                "(Difference x 15) / 5": final_amount,
                "Final Amount per person": final_amount
            }

            # Save history in session (could be replaced with DB)
            history = session.get('history', [])
            history.append(steps)
            session['history'] = history

            result = final_amount

        except ValueError:
            result = "Invalid input. Please enter numeric values."

    return render_template('calculator.html', result=result, steps=steps, user=session['user'])

@app.route('/history')
def history():
    if 'user' not in session:
        return redirect(url_for('login'))
    history = session.get('history', [])
    return render_template('history.html', history=history, user=session['user'])

@app.route('/download_pdf', methods=['POST'])
def download_pdf():
    if 'user' not in session:
        return redirect(url_for('login'))

    data = request.json
    if not data:
        return "No data provided", 400

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(0, 10, "Allaudin's EB Calculator - Calculation Details", ln=True, align='C')
    pdf.ln(10)

    for key, value in data.items():
        pdf.cell(0, 10, f"{key}: {value}", ln=True)

    pdf_output = BytesIO()
    pdf.output(pdf_output)
    pdf_output.seek(0)

    return send_file(pdf_output, as_attachment=True, download_name="eb_calculation.pdf", mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True)




