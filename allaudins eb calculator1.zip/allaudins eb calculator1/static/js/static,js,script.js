// 3D Scene Setup using Three.js (simple futuristic panel, no cubes or energy bolts)
const container = document.getElementById('threeDContainer');
if (container) {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, container.clientWidth / 300, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(container.clientWidth, 300);
    container.appendChild(renderer.domElement);

    // Neon glowing panel (a plane with emissive material)
    const geometry = new THREE.PlaneGeometry(4, 2);
    const material = new THREE.MeshBasicMaterial({ color: 0x39ff14, side: THREE.DoubleSide, opacity: 0.5, transparent: true });
    const plane = new THREE.Mesh(geometry, material);
    scene.add(plane);

    camera.position.z = 5;

    function animate() {
        requestAnimationFrame(animate);
        plane.rotation.y += 0.01;
        plane.rotation.x += 0.005;
        renderer.render(scene, camera);
    }
    animate();
}

// PDF Download Button
const downloadBtn = document.getElementById('downloadPdfBtn');
if (downloadBtn) {
    downloadBtn.addEventListener('click', () => {
        if (!calcSteps) {
            alert('No calculation data to download.');
            return;
        }
        fetch('/download_pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(calcSteps)
        })
        .then(response => response.blob())
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = "eb_calculation.pdf";
            document.body.appendChild(a);
            a.click();
            a.remove();
        })
        .catch(() => alert('Error downloading PDF'));
    });
}
